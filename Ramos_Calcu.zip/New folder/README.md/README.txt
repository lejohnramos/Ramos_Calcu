# Grade Calculator Flask App

A simple Flask web app to calculate 
final grades based on prelim, midterm, and finalterm.

Requirements

- Python 3.6 or higher
- Flask

Setup Instructions

Unzip the file

Open your VS Code and open the file in your VS Code

Install Flask:
  Click terminal/ Click New Terminal/ Click the arrow down beside +/ Select Cmd

	Type this for activating the flask:

Create an environment:
	py -3 -m venv .venv
Activate the environment:
	.venv\Scripts\activate
Install Flask:
	pip install Flask
	

Run the App: In the terminal, navigate to the folder 
where your app files are located. For example:cd path\to\your\project\folder

Then, start the Flask app by running:python Flask.py

Open in Browser: by clicking ctrl+ L click http://127.0.0.1:5000

Enter your prelim and total unpredictable grades in the provided fields.
Click "Calculate" to see your requirement grade for Midterm and Finalterm, 
as well as your final grade.

By pressing ctrl + c it will stop to run the Flask