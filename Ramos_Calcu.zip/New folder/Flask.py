from flask import Flask, render_template, request
import GradeCalcu  

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def index():
    intermediate_total = None
    final_grade = None
    
    if request.method == 'POST':
        if 'Calculate Total' in request.form:
            try:
                prelim = float(request.form['prelim'])
                total_unpredictable = float(request.form['total_unpredictable'])
                
                
                intermediate_total = GradeCalcu.calculate_intermediate_total(prelim, total_unpredictable)
                
            except ValueError:
                return render_template('text.html', result="Invalid input, please enter valid numbers.")

        elif 'Calculate Final Grade' in request.form:
            try:
                grade_input = float(request.form['grade_input'])
                
               
                final_grade = GradeCalcu.calculate_final_grade(grade_input)
                
            except ValueError:
                return render_template('text.html', result="Invalid input, please enter valid numbers.")
    
    return render_template('text.html', intermediate_total=intermediate_total, final_grade=final_grade)

if __name__ == '__main__':
    app.run(debug=True)
