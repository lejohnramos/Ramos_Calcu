def calculate_intermediate_total(prelim, total_unpredictable):
    total = prelim * 0.2
    intermediate_total = total_unpredictable - (prelim * 0.2)
    return intermediate_total

def calculate_final_grade(grade_input):
    final_grade = grade_input / 0.8
    return final_grade
